<?php
    
function listarProductos(){	
	try { 	
		$db = Conexion::getConexion();
		$stmt = $db->prepare("select * from usuario");
		$stmt->execute();
		$filas = $stmt->fetchAll(PDO::FETCH_ASSOC);			
		$arreglo = array();
		foreach($filas as $fila) {			
		    $elemento = array();
			$elemento['idUsuario'] = $fila['id_producto'];
			$elemento['nombres'] = $fila['nombres'];
			$elemento['apellidos'] = $fila['apellidos'];
			$elemento['correo'] = $fila['correo'];
			$elemento['dni'] = $fila['dni'];
			$elemento['idvivienda'] = $fila['idvivienda'];
			$elemento['password'] = $fila['password'];
			$elemento['intentos'] = $fila['intentos'];
			$elemento['tipo'] = $fila['tipo'];
			$elemento['estado'] = $fila['estado'];
			$arreglo[] = $elemento;
		}
		return $arreglo;
		
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}		
}

function buscarProductosPorNombre($dni){	
	try { 	
		$db = Conexion::getConexion();
		$stmt = $db->prepare("select * from usuario where dni like ?");
		$stmt->bindValue(1, "%$dni%", PDO::PARAM_STR);

		$stmt->execute();
		$filas = $stmt->fetchAll(PDO::FETCH_ASSOC);		
		$arreglo = array();
		foreach($filas as $fila) {			
			$elemento = array();
			$elemento['idUsuario'] = $fila['idUsuario'];
			$elemento['nombres'] = $fila['nombres'];
			$elemento['apellidos'] = $fila['apellidos'];
			$elemento['correo'] = $fila['correo'];
			$elemento['dni'] = $fila['dni'];
			$elemento['idvivienda'] = $fila['idvivienda'];
			$elemento['password'] = $fila['password'];
			$elemento['intentos'] = $fila['intentos'];
			$elemento['tipo'] = $fila['tipo'];
			$elemento['estado'] = $fila['estado'];
			$arreglo[] = $elemento;
		}
		return $arreglo;
		
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}		
}

function insertarUsuario($nombres, $apellidos, $correo, $dni, $idvivienda, $password, $intentos, $tipo, $estado){
	try { 
		$db = Conexion::getConexion();			
		$stmt = $db->prepare("insert into producto (nombres, apellidos, correo, dni, idvivienda, password, intentos, tipo, estado) values (?,?,?,?,?,?,?,?,?)");
		$datos = array($nombres, $apellidos, $correo,
					   $dni, $idvivienda, $password,
					   $intentos, $tipo, $estado);
		$db->beginTransaction();
		$stmt->execute($datos);
		$db->commit();
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}		
}

function actualizarUsuario($nombres, $apellidos, $correo, $dni, $idvivienda, $password, $intentos, $tipo, $estado){
	try { 
		$db = Conexion::getConexion();		
		$stmt = $db->prepare("update producto set nombres=?, apellidos=?, correo=?, dni=?, idvivienda=?, password=?, intentos=?, tipo=?, estado=? where idUsuario=?");
		$datos = array($nombres, $apellidos, $correo,
					   $dni, $idvivienda, $password,
					   $intentos, $tipo, $estado, $idUsuario);
		$db->beginTransaction();						
		$stmt->execute($datos);			
		$db->commit();
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}	
}

function eliminarProducto($id){
	try { 
		$db = Conexion::getConexion();  
		$stmt = $db->prepare("delete from producto where idUsuario=?");
		$datos = array($id);
		$db->beginTransaction();			
		$stmt->execute($datos);			
		$db->commit();
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}	
}


function listarAvisos(){	
	try { 	
		$db = Conexion::getConexion();
		$stmt = $db->prepare("select * from aviso");
		$stmt->execute();
		$filas = $stmt->fetchAll(PDO::FETCH_ASSOC);			
		$arreglo = array();
		foreach($filas as $fila) {			
		    $elemento = array();
			$elemento['id_aviso'] = $fila['id_aviso'];
			$elemento['titulo'] = $fila['titulo'];
			$elemento['fecha_inicio'] = $fila['fecha_inicio'];
			$elemento['fecha_fin'] = $fila['fecha_fin'];
			$elemento['estado'] = $fila['estado'];
			$elemento['id_usuario'] = $fila['id_usuario'];
			
			$arreglo[] = $elemento;
		}
		return $arreglo;
		
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}		
}

function buscarAvisos($fecha){	
	try { 	
		$db = Conexion::getConexion();
		$stmt = $db->prepare("select * from aviso where ? between fecha_inicio and fecha_fin");
		$stmt->bindValue(1, $fecha, PDO::PARAM_STR);

		$stmt->execute();
		$filas = $stmt->fetchAll(PDO::FETCH_ASSOC);		
		$arreglo = array();
		foreach($filas as $fila) {			
			$elemento = array();
			$elemento['titulo'] = $fila['titulo'];
			$elemento['fecha_inicio'] = $fila['fecha_inicio'];
			$elemento['fecha_fin'] = $fila['fecha_fin'];
			$elemento['estado'] = $fila['estado'];
                        $arreglo[] = $elemento;
		}
		return $arreglo;
		
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}		
}


function insertarAviso($titulo, $fecha_inicio, $fecha_fin){
	try { 
		$db = Conexion::getConexion();			
		$stmt = $db->prepare("insert into aviso (titulo,fecha_inicio,fecha_fin,estado) values (?,?,?,'1')");
		$datos = array($titulo, $fecha_inicio, $fecha_fin);
		$db->beginTransaction();
		$stmt->execute($datos);
		$db->commit();
	} catch (PDOException $e) {
		$db->rollback();
		$mensaje  = '<b>Consulta inválida:</b> ' . $e->getMessage() . "<br/>";
		die($mensaje);
	}		
}

?>